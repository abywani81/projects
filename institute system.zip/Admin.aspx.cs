﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Buttonlogin_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection("Data Source=WORKSTATION5\\SQLEXPRESS;Initial Catalog = institutemangement;Integrated Security = true");
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from adminlogin where username=@username and password=@password", con);
        cmd.Parameters.AddWithValue("@username", TextBoxuser.Text);
        cmd.Parameters.AddWithValue("@password", TextBoxpass.Text);
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);

       if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["username"].ToString() == TextBoxuser.Text && dt.Rows[0]["password"].ToString() == TextBoxpass.Text)
            {
                Response.Redirect("studentdetails.aspx");
            }
            else
            {
                Labellogin.Text = "Invalid Username or password";
            }
        }
    }
}