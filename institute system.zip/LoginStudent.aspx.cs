﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Buttonregister_Click(object sender, EventArgs e)
    {
        Response.Redirect("StudentRegister.aspx");

    }

    protected void Buttonlogin_Click(object sender, EventArgs e)
    {
        Session["sess"] = TextBoxuser.Text;
        SqlConnection con = new SqlConnection("Data Source=WORKSTATION5\\SQLEXPRESS;Initial Catalog = institutemangement;Integrated Security = true");
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from addstudent where username=@username and password=@password", con);
        cmd.Parameters.AddWithValue("@username", TextBoxuser.Text);
        cmd.Parameters.AddWithValue("@password", TextBoxpass.Text);
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);

        if (dt.Rows.Count > 0)
            {
               Response.Redirect("Viewstudentlogin.aspx");
                
            }
            else
            {
                Labeluser.Text = "Invalid Username or password";
            }
        }

    }
