﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;



public partial class StudentRegister : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack == true)
        {
            SqlConnection con = new SqlConnection("Data Source=WORKSTATION5\\SQLEXPRESS;Initial Catalog = institutemangement;Integrated Security = true");
            con.Open();
            SqlDataAdapter adp = new SqlDataAdapter("select * from addcourse", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            DropDownListcourse.DataSource = dt;
            DropDownListcourse.DataBind();
            DropDownListcourse.DataTextField = "choosecourse";
            DropDownListcourse.DataValueField = "courseid";
            DropDownListcourse.DataBind();
        }
    }


    protected void DropDownListcourse_SelectedIndexChanged(object sender, EventArgs e)
    {

        try
        {
           
                SqlConnection con = new SqlConnection("Data Source=WORKSTATION5\\SQLEXPRESS;Initial Catalog = institutemangement;Integrated Security = true");
                con.Open();
                SqlDataAdapter adp = new SqlDataAdapter("select * from addcourse where choosecourse='"+DropDownListcourse.SelectedItem.Text+"'", con);
                DataTable dt = new DataTable();
                adp.Fill(dt);
             
                
                TextBoxcourse.Text = dt.Rows[0]["courseduration"].ToString();
                TextBoxamount.Text = dt.Rows[0]["courseamount"].ToString();
                TextBoxdiscount.Text = dt.Rows[0]["coursediscount"].ToString();
                TextBoxtotal.Text = dt.Rows[0]["totalamount"].ToString();
            }
        
        catch (Exception ex)
        {


        }
    }



    protected void Buttonsubmit_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            string imagepath;
            string filename = Path.GetExtension(FileUpload1.FileName);

            FileUpload1.SaveAs(Server.MapPath("images/" + FileUpload1.FileName));
            imagepath = "images/" + FileUpload1.FileName;
            


            SqlConnection con = new SqlConnection("Data Source=WORKSTATION5\\SQLEXPRESS;Initial Catalog = institutemangement;Integrated Security = true");
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into addstudent values('" +TextBoxfirst.Text + "','" +TextBoxlast.Text+ "','" +TextBoxparent.Text+ "','" +TextBoxaddress.Text+ "','" +TextBoxdob.Text + "','" +TextBoxmobile.Text+ "','" +TextBoxemail.Text+"','" +TextBoxpin.Text+"','" +DropDownListgender.SelectedItem.Text+"','" + DropDownListcourse.SelectedItem.Text+"','" +TextBoxcourse.Text +"','" +TextBoxamount.Text+"','" +TextBoxdiscount.Text +"','" +TextBoxtotal.Text +"','" +imagepath+"','" +TextBoxuser.Text+"','" +TextBoxpass.Text +"')", con);
        cmd.ExecuteNonQuery();
            Labelsubmit.Text = "Data Submitted Successfully";

        }
    }
}