﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Viewstudentlogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["sess"] == null)
        {
            Response.Redirect("LoginStudent.aspx");
        }
        else
        {
            SqlConnection con1 = new SqlConnection("Data Source=WORKSTATION5\\SQLEXPRESS;Initial Catalog = institutemangement;Integrated Security = true");
            con1.Open();
            SqlDataAdapter adp1 = new SqlDataAdapter("select * from addstudent where username='"+Session["sess"].ToString()+"'", con1);
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);
            TextBoxfirst.Text = dt1.Rows[0]["firstname"].ToString();
            TextBoxlast.Text = dt1.Rows[0]["lastname"].ToString();
            TextBoxparent.Text = dt1.Rows[0]["parentage"].ToString();
            TextBoxaddress.Text = dt1.Rows[0]["address"].ToString();
            TextBoxdob.Text = dt1.Rows[0]["dob"].ToString();
            TextBoxmobile.Text = dt1.Rows[0]["mobileno"].ToString();
            TextBoxemail.Text = dt1.Rows[0]["email"].ToString();
            TextBoxpin.Text = dt1.Rows[0]["pincode"].ToString();
            TextBoxgender.Text = dt1.Rows[0]["gender"].ToString();
            TextBoxchoosecourse.Text = dt1.Rows[0]["choosecourse"].ToString();
            TextBoxcourse.Text = dt1.Rows[0]["courseduration"].ToString();
            TextBoxamount.Text = dt1.Rows[0]["courseamount"].ToString();

            TextBoxdiscount.Text = dt1.Rows[0]["coursediscount"].ToString();
            TextBoxtotal.Text = dt1.Rows[0]["totalamount"].ToString();
            Image1.ImageUrl = dt1.Rows[0]["choosefile"].ToString();
        }

    }

   
}