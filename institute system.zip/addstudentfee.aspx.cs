﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class addstudentfee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Buttoncalculate_Click(object sender, EventArgs e)
    {
        int totalfee = Convert.ToInt32(TextBoxtotalfee.Text);
        int feepaid = Convert.ToInt32(TextBoxfeepaid.Text);
 
        int total =totalfee-feepaid;
        TextBoxremainingfee.Text = total.ToString();
    }

    protected void Buttonsubmit_Click(object sender, EventArgs e)
    {
       
        SqlConnection con = new SqlConnection("Data Source=WORKSTATION5\\SQLEXPRESS;Initial Catalog = institutemangement;Integrated Security = true");
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into addstudentfee values('"+TextBoxsearch.Text+"','" + TextBoxfirstname.Text+ "','" +TextBoxlastname.Text + "','" +TextBoxparentage.Text+ "','" +TextBoxtotalfee.Text + "','" +TextBoxfeepaid.Text + "','" +TextBoxremainingfee.Text + "','"+TextBoxdate.Text+"')", con);
        cmd.ExecuteNonQuery();
        con.Close();
        Labelsubmit.Text = "Data Submitted Sucessfully";
        TextBoxfirstname.Text = "";
        TextBoxlastname.Text = "";
        TextBoxparentage.Text = "";
        TextBoxtotalfee.Text = "";
        TextBoxfeepaid.Text = "";
        TextBoxremainingfee.Text = "";
        TextBoxdate.Text = "";

    }
    

    protected void Buttonsearch_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection("Data Source=WORKSTATION5\\SQLEXPRESS;Initial Catalog = institutemangement;Integrated Security = true");
        con.Open();
        SqlDataAdapter adp = new SqlDataAdapter("select * from addstudent where studentid='" + TextBoxsearch.Text + "'", con);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        if (dt.Rows.Count > 0)

        {
            TextBoxfirstname.Text = dt.Rows[0]["firstname"].ToString();
            TextBoxlastname.Text = dt.Rows[0]["lastname"].ToString();
            TextBoxparentage.Text = dt.Rows[0]["parentage"].ToString();
            TextBoxtotalfee.Text = dt.Rows[0]["totalamount"].ToString();
        }
        else {
            Labelsearch.Text = "Invalid ID";
        }
    }
}