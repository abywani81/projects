﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class studentdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_course(object sender, EventArgs e)
    {
        Response.Redirect("addstudentcourse.aspx");
    }

    protected void Button2_fee(object sender, EventArgs e)
    {
        Response.Redirect("addstudentfee.aspx");
    }

    protected void Button3_view(object sender, EventArgs e)
    {
        Response.Redirect("viewstudent.aspx");
    }
}



   